/*
 * SYSTICK.H
 *
 *  Created on: Jul 27, 2024
 *      Author: Mina
 */

#ifndef SYSTICK_H_
#define SYSTICK_H_

/******************************************************************************
*                                Inclusions                                   *
*******************************************************************************/

#include "std_types.h"

/******************************************************************************
*                           Preprocessor Definitions                          *
*******************************************************************************/

#define CPU_FREQ    16000000u
#define MILLI_SEC    0.001f
#define MAX_RELOAD  16000000u


/*******************************************************************************************************
*                                        Functions prototype                                           *
********************************************************************************************************/

/* Initialize the SysTick timer with the specified time in milliseconds using interrupts.*/
void SysTick_Init(uint16 a_TimeInMilliSeconds);

/*Initialize the SysTick timer with the specified time in milliseconds using polling or busy-wait technique.*/
void SysTick_StartBusyWait(uint16 a_TimeInMilliSeconds);

/*Function to setup the SysTick Timer call back to be executed in SysTick Handler.*/
void SysTick_SetCallBack(volatile void (*Ptr2Func) (void));

/*Stop the SysTick timer.*/
void SysTick_Stop(void);

/*Start/Resume the SysTick timer.*/
void SysTick_Start(void);

/*Function to De-initialize the SysTick Timer.*/
void SysTick_DeInit(void);

/************************************************************************************
 *                                 End of File                                      *
 ************************************************************************************/

#endif /* SYSTICK_H_ */
